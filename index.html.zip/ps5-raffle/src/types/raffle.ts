export type EntryStatus = "PENDING" | "VERIFIED" | "REJECTED";

export interface RaffleEntry {
  id: string;
  email: string;
  txid: string;
  tickets: number;
  amount: number;
  createdAt: string;
  status: EntryStatus;
  raffleNumber?: string;
}

import { useState } from "react";
import { ChevronDown } from "lucide-react";

const questions = [
  ["How does the PlayStation 5 raffle work?", "Choose a ticket package, follow the USDT TRC20 payment instructions, and submit your transaction hash and email. Your submission remains pending until payment is independently verified."],
  ["How much does one ticket cost?", "The example packages are 1 ticket for $10, 3 tickets for $25, and 5 tickets for $40 USDT. Confirm the final prices in the published official rules before launch."],
  ["Why is USDT TRC20 the only payment method?", "This demonstration is configured to show USDT on the TRON network only. Always check the network and token carefully before sending."],
  ["What if I send through the wrong network?", "Funds sent using an unsupported coin or network may be permanently lost. Contact your wallet provider immediately; recovery is not guaranteed."],
  ["Where can I find my TXID?", "Open the transaction details in your wallet and copy the transaction ID or transaction hash. Make sure it corresponds to the payment you made."],
  ["When will I receive my raffle number?", "Only after the operator independently verifies the transaction and confirms eligibility. This frontend cannot assign or email a valid raffle number."],
  ["When will the winner be announced?", "The actual draw date and time must be published in the official rules before entries open."],
  ["How will the winner be selected?", "Publish the exact selection process, independent verification method, and draw record in the official rules before accepting entries."],
  ["How will the prize be delivered?", "Delivery terms, eligible locations, shipping costs, customs, and warranty details must be stated in the official rules."],
  ["Is this raffle legal?", "Rules vary by jurisdiction. Obtain qualified legal advice and all required licenses before operating a paid raffle."],
  ["How can I verify that the raffle is legitimate?", "Review the organizer's legal identity, published rules, prize evidence, draw method, and independently verifiable records. Do not rely on this demo page alone."]
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section className="section-wrap">
      <div className="section-heading"><span className="eyebrow">NEED TO KNOW</span><h2>Frequently asked <span className="gradient-text">questions</span></h2></div>
      <div className="mx-auto max-w-3xl space-y-3">
        {questions.map(([q, a], i) => (
          <div className="faq-item" key={q}>
            <button className="flex w-full items-center justify-between gap-4 text-left font-bold" onClick={() => setOpen(open === i ? null : i)} aria-expanded={open === i}>
              {q}<ChevronDown size={18} className={`shrink-0 text-cyan-300 transition ${open === i ? "rotate-180" : ""}`} />
            </button>
            {open === i && <p className="mt-3 text-sm leading-7 text-slate-400">{a}</p>}
          </div>
        ))}
      </div>
    </section>
  );
}

import { useEffect, useState } from "react";
import { RAFFLE_END } from "../lib/constants";

export default function Countdown() {
  const [remaining, setRemaining] = useState("");
  useEffect(() => {
    const update = () => {
      const diff = Math.max(0, new Date(RAFFLE_END).getTime() - Date.now());
      const days = Math.floor(diff / 86400000);
      const hours = Math.floor((diff % 86400000) / 3600000);
      const minutes = Math.floor((diff % 3600000) / 60000);
      const seconds = Math.floor((diff % 60000) / 1000);
      setRemaining(`${days}d ${hours}h ${minutes}m ${seconds}s`);
    };
    update();
    const id = window.setInterval(update, 1000);
    return () => window.clearInterval(id);
  }, []);
  return <span className="font-mono font-bold text-cyan-300">{remaining}</span>;
}

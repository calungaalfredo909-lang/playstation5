import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState } from "react";
import { CheckCircle2, Users } from "lucide-react";

const demo = [
  { name: "Michael", city: "London", amount: 10, tickets: 1, ago: "2 min ago" },
  { name: "Sarah", city: "Lagos", amount: 25, tickets: 3, ago: "4 min ago" },
  { name: "David", city: "New York", amount: 40, tickets: 5, ago: "6 min ago" },
  { name: "Ana", city: "Lisbon", amount: 10, tickets: 1, ago: "8 min ago" },
  { name: "James", city: "Manchester", amount: 25, tickets: 3, ago: "10 min ago" },
];

export default function ParticipantToast() {
  const [index, setIndex] = useState(-1);
  useEffect(() => {
    let timeout: number;
    const schedule = () => {
      timeout = window.setTimeout(() => {
        setIndex((current) => (current + 1) % demo.length);
        window.setTimeout(() => setIndex(-1), 5600);
        schedule();
      }, 12000 + Math.random() * 13000);
    };
    schedule();
    return () => window.clearTimeout(timeout);
  }, []);
  const item = index >= 0 ? demo[index] : null;
  return (
    <div className="fixed bottom-4 left-4 z-40 max-w-[calc(100vw-2rem)]">
      <AnimatePresence>
        {item && (
          <motion.div initial={{ opacity: 0, x: -35, y: 20 }} animate={{ opacity: 1, x: 0, y: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ type: "spring", stiffness: 260, damping: 22 }} className="toast-card">
            <div className="avatar">{item.name.slice(0, 1)}</div>
            <div className="min-w-0">
              <div className="flex items-center gap-1 text-xs font-bold text-white"><span>{item.name} · {item.city}</span><CheckCircle2 size={13} className="text-emerald-400" /></div>
              <p className="mt-1 text-[11px] text-slate-300">DEMO: ${item.amount} · {item.tickets} ticket{item.tickets > 1 ? "s" : ""} · {item.ago}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <div className="mt-2 inline-flex items-center gap-1 rounded-full border border-cyan-900/70 bg-slate-950/90 px-2 py-1 text-[9px] font-bold tracking-widest text-cyan-300"><Users size={10}/> SAMPLE ACTIVITY — DEMO ONLY</div>
    </div>
  );
}

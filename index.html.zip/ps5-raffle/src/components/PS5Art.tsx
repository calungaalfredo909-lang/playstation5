type Props = { variant?: "hero" | "front" | "side" | "controller"; className?: string };

export default function PS5Art({ variant = "hero", className = "" }: Props) {
  if (variant === "controller") {
    return (
      <svg className={className} viewBox="0 0 520 300" role="img" aria-label="Stylized white and black DualSense-inspired wireless controller illustration">
        <defs>
          <linearGradient id="pad" x1="0" x2="1" y1="0" y2="1"><stop stopColor="#fff"/><stop offset="1" stopColor="#9daec7"/></linearGradient>
          <filter id="glow"><feGaussianBlur stdDeviation="9" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
        </defs>
        <ellipse cx="260" cy="244" rx="170" ry="20" fill="#00baff" opacity=".22" filter="url(#glow)"/>
        <path d="M95 145 Q105 70 180 88 L230 105 L290 105 L340 88 Q415 70 425 145 L450 205 Q455 235 425 240 L370 220 L330 180 L190 180 L150 220 L95 240 Q65 235 70 205Z" fill="url(#pad)" stroke="#dbeafe" strokeWidth="5"/>
        <path d="M180 92 Q260 118 340 92 L326 169 L194 169Z" fill="#111827"/>
        <rect x="239" y="128" width="42" height="34" rx="8" fill="#0b1220" stroke="#7dd3fc" strokeWidth="2"/>
        <circle cx="148" cy="158" r="23" fill="#1e293b"/><circle cx="148" cy="158" r="13" fill="#64748b"/>
        <circle cx="370" cy="158" r="23" fill="#1e293b"/><circle cx="370" cy="158" r="13" fill="#64748b"/>
        <path d="M208 130 h22 M219 119 v22" stroke="#e2e8f0" strokeWidth="6" strokeLinecap="round"/>
        <g fill="#0ea5e9"><circle cx="344" cy="125" r="7"/><circle cx="365" cy="145" r="7"/><circle cx="323" cy="145" r="7"/><circle cx="344" cy="165" r="7"/></g>
      </svg>
    );
  }
  const side = variant === "side";
  const front = variant === "front";
  return (
    <svg className={className} viewBox="0 0 520 620" role="img" aria-label={side ? "Side profile illustration of a PlayStation 5-style console" : "Futuristic white and black PlayStation 5 console illustration with blue lighting"}>
      <defs>
        <linearGradient id="whitePanel" x1="0" x2="1" y1="0" y2="1"><stop stopColor="#fff"/><stop offset=".55" stopColor="#dce7f5"/><stop offset="1" stopColor="#8da4c2"/></linearGradient>
        <linearGradient id="blackCore" x1="0" x2="1"><stop stopColor="#101827"/><stop offset=".5" stopColor="#020617"/><stop offset="1" stopColor="#26364d"/></linearGradient>
        <linearGradient id="blueEdge" x1="0" x2="1"><stop stopColor="#0070f3"/><stop offset=".5" stopColor="#00d9ff"/><stop offset="1" stopColor="#003791"/></linearGradient>
        <filter id="blueGlow"><feGaussianBlur stdDeviation="13" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
      </defs>
      <ellipse cx="260" cy="560" rx="160" ry="24" fill="#0070f3" opacity=".28" filter="url(#blueGlow)"/>
      {side ? (
        <g transform="translate(115 35)">
          <path d="M125 18 Q155 4 174 30 L204 510 Q200 535 177 542 L110 535 Q90 525 94 500 L76 62 Q82 28 125 18Z" fill="url(#whitePanel)" stroke="#fff" strokeWidth="4"/>
          <path d="M130 28 L161 520 L130 522 L105 48Z" fill="url(#blackCore)"/>
          <path d="M165 48 L190 495" stroke="url(#blueEdge)" strokeWidth="5" filter="url(#blueGlow)"/>
        </g>
      ) : (
        <g transform={front ? "translate(0 0)" : "translate(10 0) skewY(-4)"}>
          <path d="M180 35 Q105 45 90 105 L115 505 Q120 540 160 548 L205 535 L190 70Z" fill="url(#whitePanel)" stroke="#fff" strokeWidth="4"/>
          <path d="M340 35 Q415 45 430 105 L405 505 Q400 540 360 548 L315 535 L330 70Z" fill="url(#whitePanel)" stroke="#fff" strokeWidth="4"/>
          <path d="M190 48 Q260 20 330 48 L322 535 Q260 565 198 535Z" fill="url(#blackCore)" stroke="#334155" strokeWidth="3"/>
          <path d="M190 65 Q260 35 330 65" stroke="#00cfff" strokeWidth="5" opacity=".9" filter="url(#blueGlow)"/>
          <path d="M198 520 Q260 548 322 520" stroke="url(#blueEdge)" strokeWidth="5" filter="url(#blueGlow)"/>
          <g opacity=".35" stroke="#94a3b8" strokeWidth="2">
            {Array.from({length: 9}, (_, i) => <path key={i} d={`M${207 + i*12} 105 l-2 340`} />)}
          </g>
          <rect x="246" y="510" width="28" height="8" rx="4" fill="#e2e8f0"/>
          <circle cx="260" cy="495" r="4" fill="#00d9ff"/>
        </g>
      )}
    </svg>
  );
}

import { useMemo, useState } from "react";
import { QRCodeSVG } from "qrcode.react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useNavigate } from "react-router-dom";
import { Check, Copy, ShieldAlert, Wallet } from "lucide-react";
import { PACKAGES, WALLET_ADDRESS } from "../lib/constants";
import { entrySchema, type EntryFormValues } from "../lib/validation";
import { saveEntry } from "../lib/storage";
import type { RaffleEntry } from "../types/raffle";

export default function PaymentSection() {
  const [selected, setSelected] = useState(1);
  const [copied, setCopied] = useState(false);
  const navigate = useNavigate();
  const current = useMemo(() => PACKAGES.find((p) => p.tickets === selected)!, [selected]);
  const { register, handleSubmit, setValue, formState: { errors, isSubmitting } } = useForm<EntryFormValues>({
    resolver: zodResolver(entrySchema),
    defaultValues: { tickets: 1 },
  });

  const copyAddress = async () => {
    try {
      await navigator.clipboard.writeText(WALLET_ADDRESS);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2200);
    } catch {
      alert("Copy is unavailable in this browser. Please select and copy the wallet address manually.");
    }
  };

  const onSubmit = (values: EntryFormValues) => {
    const pkg = PACKAGES.find((p) => p.tickets === Number(values.tickets));
    if (!pkg) return;
    const entry: RaffleEntry = {
      id: crypto.randomUUID(),
      email: values.email,
      txid: values.txid,
      tickets: pkg.tickets,
      amount: pkg.amount,
      createdAt: new Date().toISOString(),
      status: "PENDING",
    };
    saveEntry(entry);
    navigate("/thank-you", { state: { entry } });
  };

  return (
    <section id="payment" className="section-wrap">
      <div className="section-heading">
        <span className="eyebrow"><Wallet size={14}/> SECURE YOUR ENTRY</span>
        <h2>Enter the <span className="gradient-text">raffle</span></h2>
        <p>Choose a ticket package, send USDT on TRON (TRC20), then submit your transaction hash for manual review.</p>
      </div>
      <div className="payment-grid">
        <div className="glass-card">
          <h3 className="mb-1 text-xl font-extrabold">1. Choose your package</h3>
          <p className="mb-5 text-sm text-slate-400">Your total updates automatically.</p>
          <div className="grid gap-3 sm:grid-cols-3">
            {PACKAGES.map((pkg) => (
              <button key={pkg.tickets} type="button" onClick={() => { setSelected(pkg.tickets); setValue("tickets", pkg.tickets, { shouldValidate: true }); }} className={`package-option ${selected === pkg.tickets ? "selected" : ""}`}>
                {pkg.popular && <span className="package-tag">POPULAR</span>}
                {pkg.best && <span className="package-tag">BEST VALUE</span>}
                <strong>{pkg.tickets}</strong><span className="text-xs text-slate-300">Tickets</span>
                <b>${pkg.amount}</b><small>{pkg.note}</small>
              </button>
            ))}
          </div>
          <div className="mt-6 rounded-2xl border border-cyan-500/20 bg-cyan-400/5 p-4">
            <div className="flex items-center justify-between text-sm text-slate-300"><span>Selected package</span><b>{current.tickets} ticket{current.tickets > 1 ? "s" : ""}</b></div>
            <div className="mt-2 flex items-center justify-between"><span className="text-sm text-slate-300">Total to send</span><strong className="text-3xl font-black text-white">${current.amount} <small className="text-sm text-cyan-300">USDT</small></strong></div>
          </div>
          <div className="mt-6 flex flex-col items-center rounded-2xl bg-white p-5 text-center">
            <QRCodeSVG value={WALLET_ADDRESS} size={180} level="H" includeMargin />
            <p className="mt-3 text-xs font-bold tracking-widest text-slate-900">USDT · TRON (TRC20)</p>
            <p className="mt-1 text-[11px] text-slate-600">Scan using a compatible wallet.</p>
          </div>
          <div className="mt-5">
            <label className="field-label">USDT TRC20 wallet address</label>
            <div className="wallet-address">{WALLET_ADDRESS}</div>
            <button onClick={copyAddress} type="button" className="btn-secondary mt-3 w-full">{copied ? <Check size={16}/> : <Copy size={16}/>} {copied ? "Copied!" : "Copy address"}</button>
          </div>
          <div className="warning-box mt-5"><ShieldAlert size={20} className="shrink-0"/><p><b>NETWORK WARNING:</b> Only send USDT on the TRON (TRC20) network. Sending any other coin or using another network may result in permanent loss of funds.</p></div>
          <p className="mt-4 text-xs leading-5 text-slate-500">Network fees are set by the TRON network and your wallet. Check the fee displayed by your wallet before confirming. This site does not provide a live fee quote.</p>
        </div>

        <div className="glass-card">
          <h3 className="mb-1 text-xl font-extrabold">2. Submit your transaction</h3>
          <p className="mb-5 text-sm text-slate-400">After sending the exact amount, paste your TXID below.</p>
          <ol className="steps-list">
            <li><span>1</span>Open your wallet.</li>
            <li><span>2</span>Select USDT (TRC20).</li>
            <li><span>3</span>Send exactly <b>${current.amount} USDT</b>.</li>
            <li><span>4</span>Copy the transaction hash (TXID).</li>
            <li><span>5</span>Paste your TXID and email below, then submit.</li>
          </ol>
          <form onSubmit={handleSubmit(onSubmit)} className="mt-7 space-y-4">
            <div>
              <label className="field-label" htmlFor="email">Email address</label>
              <input id="email" type="email" placeholder="you@example.com" className="form-input" {...register("email")} />
              {errors.email && <p className="form-error">{errors.email.message}</p>}
            </div>
            <div>
              <label className="field-label" htmlFor="txid">Transaction hash (TXID)</label>
              <textarea id="txid" rows={4} placeholder="Paste your TRON transaction hash" className="form-input resize-y" {...register("txid")} />
              {errors.txid && <p className="form-error">{errors.txid.message}</p>}
            </div>
            <input type="hidden" value={selected} {...register("tickets")} />
            {errors.tickets && <p className="form-error">{errors.tickets.message}</p>}
            <div className="rounded-xl border border-amber-400/20 bg-amber-400/5 p-3 text-xs leading-5 text-amber-100/80">
              Your submission is saved as <b>PENDING</b> in this browser only. Submitting a TXID does not verify payment or reserve a ticket.
            </div>
            <button className="btn-primary w-full" type="submit" disabled={isSubmitting}>Submit entry <span>→</span></button>
          </form>
          <p className="mt-4 text-center text-xs leading-5 text-slate-500">Manual review is required. The advertised 30-minute review target is not a guarantee; timing depends on network confirmation and the operator's review.</p>
        </div>
      </div>
    </section>
  );
}

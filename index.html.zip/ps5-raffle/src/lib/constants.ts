export const WALLET_ADDRESS = "TH8ieZmdYvWkAm17b8wDDuhb5RYMFU5gJb";

export const PACKAGES = [
  { tickets: 1, amount: 10, label: "1 Ticket", note: "Single entry" },
  { tickets: 3, amount: 25, label: "3 Tickets", note: "Popular choice", popular: true },
  { tickets: 5, amount: 40, label: "5 Tickets", note: "Best value", best: true },
] as const;

// Replace with the real published closing date before launch.
export const RAFFLE_END = "2027-01-31T20:00:00Z";

// These are demonstration figures. Do not present them as live inventory.
export const DEMO_PROGRESS = { sold: 847, total: 1000 };

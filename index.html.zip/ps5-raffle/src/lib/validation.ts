import { z } from "zod";

export const entrySchema = z.object({
  email: z.string().trim().email("Please enter a valid email address."),
  txid: z.string().trim().min(20, "Please enter your transaction hash.").max(160, "TXID is too long."),
  tickets: z.coerce.number().refine((n) => [1, 3, 5].includes(n), "Choose a valid ticket package."),
});

export type EntryFormValues = z.infer<typeof entrySchema>;

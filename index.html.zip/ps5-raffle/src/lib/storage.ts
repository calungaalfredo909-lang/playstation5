import type { RaffleEntry } from "../types/raffle";

const KEY = "ps5-raffle-entries";

export function getEntries(): RaffleEntry[] {
  try {
    return JSON.parse(localStorage.getItem(KEY) || "[]") as RaffleEntry[];
  } catch {
    return [];
  }
}

export function saveEntry(entry: RaffleEntry): void {
  const entries = getEntries();
  localStorage.setItem(KEY, JSON.stringify([entry, ...entries]));
}

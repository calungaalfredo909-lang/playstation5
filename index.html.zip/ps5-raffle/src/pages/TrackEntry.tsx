import { useState } from "react";
import { Link } from "react-router-dom";
import { Search } from "lucide-react";
import { getEntries } from "../lib/storage";
import type { RaffleEntry } from "../types/raffle";

export default function TrackEntry() {
  const [email, setEmail] = useState("");
  const [results, setResults] = useState<RaffleEntry[] | null>(null);
  const search = (e: React.FormEvent) => {
    e.preventDefault();
    setResults(getEntries().filter((entry) => entry.email.toLowerCase() === email.trim().toLowerCase()));
  };
  return <main className="min-h-screen px-5 py-20">
    <div className="mx-auto max-w-2xl glass-card">
      <span className="eyebrow">ENTRY LOOKUP</span><h1 className="mt-3 text-3xl font-black">Track your <span className="gradient-text">entry</span></h1>
      <p className="mt-3 text-sm leading-7 text-slate-400">Enter the same email address used when submitting. This demo searches only the current browser's local storage.</p>
      <form onSubmit={search} className="mt-7 flex flex-col gap-3 sm:flex-row"><input className="form-input" type="email" required placeholder="Your email address" value={email} onChange={(e) => setEmail(e.target.value)}/><button className="btn-primary shrink-0"><Search size={16}/> Search</button></form>
      {results && <div className="mt-6 space-y-3">{results.length ? results.map((entry) => <div key={entry.id} className="rounded-xl border border-white/10 bg-slate-950/60 p-4 text-sm"><div className="flex justify-between"><b>{entry.tickets} ticket(s)</b><span className="text-amber-300">{entry.status}</span></div><p className="mt-2 text-slate-400">Amount: ${entry.amount} USDT</p><p className="break-all text-xs text-slate-500">TXID: {entry.txid}</p><p className="mt-1 text-xs text-slate-500">{new Date(entry.createdAt).toLocaleString()}</p></div>) : <p className="rounded-xl bg-slate-950 p-4 text-sm text-slate-400">No entries found for this email in this browser.</p>}</div>}
      <p className="mt-6 text-xs text-slate-500">Local storage is device- and browser-specific. For reliable status lookup across devices, connect a secure backend.</p>
      <Link to="/" className="mt-7 inline-block text-sm font-bold text-cyan-300">← Back to homepage</Link>
    </div>
  </main>;
}

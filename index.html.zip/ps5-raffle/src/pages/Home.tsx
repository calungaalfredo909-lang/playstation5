import { motion } from "framer-motion";
import { ArrowRight, CheckCircle2, Gamepad2, LockKeyhole, ShieldCheck, Trophy, Zap } from "lucide-react";
import Countdown from "../components/Countdown";
import PS5Art from "../components/PS5Art";
import PaymentSection from "../components/PaymentSection";
import FAQ from "../components/FAQ";
import { DEMO_PROGRESS } from "../lib/constants";

export default function Home() {
  const scrollToPayment = () => document.getElementById("payment")?.scrollIntoView({ behavior: "smooth" });
  return (
    <>
      <div className="top-strip"><span className="pulse-dot"/> RAFFLE PREVIEW · DEMO COUNTER · <span>ENDS IN <Countdown/></span></div>
      <header className="site-nav">
        <a href="/" className="brand"><span className="brand-mark">P</span><span>PLAY<span className="text-cyan-300">WIN</span></span></a>
        <nav><a href="#how">How it works</a><a href="#prize">The prize</a><a href="#rules">Rules</a></nav>
        <button onClick={scrollToPayment} className="nav-cta">Enter raffle <ArrowRight size={15}/></button>
      </header>

      <main>
        <section className="hero section-wrap">
          <div className="hero-copy">
            <div className="eyebrow"><span className="pulse-dot"/> THE NEXT LEVEL STARTS HERE</div>
            <h1>WIN A BRAND-NEW <span className="gradient-text">PLAYSTATION 5</span> FOR JUST <span className="price-glow">$10!</span></h1>
            <p className="hero-sub">Your next gaming adventure could start with one entry. Explore the details, review the rules, and enter for a chance to take home the legendary PlayStation 5.</p>
            <div className="flex flex-wrap gap-3">
              <button onClick={scrollToPayment} className="btn-primary">ENTER THE RAFFLE NOW <ArrowRight size={18}/></button>
              <a href="#how" className="btn-secondary">How it works</a>
            </div>
            <div className="hero-trust">
              <span><ShieldCheck size={16}/> Transparent rules</span><span><LockKeyhole size={16}/> TRC20 instructions</span><span><Trophy size={16}/> Prize details</span>
            </div>
          </div>
          <motion.div className="hero-art" initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .8 }}>
            <div className="art-orbit orbit-one"/><div className="art-orbit orbit-two"/>
            <div className="art-glow"/>
            <PS5Art className="w-full max-w-[470px] drop-shadow-2xl"/>
            <div className="floating-chip"><Gamepad2 size={16}/> NEXT-GEN GAMING</div>
          </motion.div>
          <div className="hero-bottom">
            <div><small>DEMO RAFFLE PROGRESS</small><div className="progress-track"><div style={{width: `${DEMO_PROGRESS.sold/DEMO_PROGRESS.total*100}%`}}/></div><b>{DEMO_PROGRESS.sold} <span>/ {DEMO_PROGRESS.total}</span></b><small className="block text-slate-500">Illustrative figures only — not live inventory</small></div>
            <div className="countdown-card"><small>TIME REMAINING</small><strong><Countdown/></strong><small className="text-slate-500">Demo end date — update before launch</small></div>
          </div>
        </section>

        <section id="how" className="section-wrap section-muted">
          <div className="section-heading"><span className="eyebrow">SIMPLE ENTRY PROCESS</span><h2>How it <span className="gradient-text">works</span></h2><p>Four steps from choosing your package to submitting your transaction for review.</p></div>
          <div className="steps-grid">
            {[["01","Choose your tickets","Select 1, 3, or 5 entries."],["02","Send your payment","Send the exact USDT amount using TRON (TRC20)."],["03","Submit your TXID","Paste your transaction hash and email address."],["04","Wait for verification","Your entry can be confirmed only after manual payment review."]].map(([n,t,d]) => <div className="step-card" key={n}><span>{n}</span><h3>{t}</h3><p>{d}</p></div>)}
          </div>
        </section>

        <section id="prize" className="section-wrap prize-section">
          <div className="prize-art"><PS5Art className="w-full max-w-[390px]"/><div className="prize-caption">CONSOLE ARTWORK · ILLUSTRATIVE</div></div>
          <div className="prize-copy"><span className="eyebrow"><Trophy size={14}/> THE FEATURED PRIZE</span><h2>Meet your next <span className="gradient-text">gaming obsession.</span></h2><p className="text-slate-400 leading-7">The PlayStation 5 brings ultra-high-speed SSD performance, 4K gaming support, ray tracing capabilities, immersive 3D audio, and the DualSense wireless controller.</p>
            <div className="feature-list"><span><CheckCircle2/> Ultra-high-speed SSD</span><span><CheckCircle2/> 4K gaming and ray tracing support</span><span><CheckCircle2/> DualSense wireless controller</span><span><CheckCircle2/> PS5 game library compatibility</span></div>
            <div className="value-line"><span>Illustrative prize value</span><b>$499</b></div><p className="text-xs text-slate-500">Illustrative value only. Confirm the exact console edition, condition, included accessories, warranty, and local market value before launch. No games are included unless explicitly listed in the official rules.</p>
            <button onClick={scrollToPayment} className="btn-primary mt-6">CHOOSE YOUR TICKETS <ArrowRight size={18}/></button>
          </div>
        </section>

        <section className="section-wrap section-muted">
          <div className="section-heading"><span className="eyebrow">BUILT AROUND CLARITY</span><h2>Know before you <span className="gradient-text">enter</span></h2></div>
          <div className="trust-grid">
            <div><ShieldCheck/><h3>Transparent rules</h3><p>Review eligibility, dates, draw procedure, and delivery terms before participating.</p></div>
            <div><LockKeyhole/><h3>Clear payment steps</h3><p>Payment instructions identify the token and network. Always verify the address yourself.</p></div>
            <div><Zap/><h3>Manual review</h3><p>Submissions remain pending until the transaction is independently checked.</p></div>
          </div>
        </section>

        <PaymentSection/>
        <FAQ/>

        <section id="rules" className="section-wrap">
          <div className="rules-panel">
            <div><span className="eyebrow">READ THE DETAILS</span><h2>Transparency comes <span className="gradient-text">first.</span></h2><p className="mt-3 max-w-2xl text-sm leading-7 text-slate-400">Before accepting entries, publish complete official rules covering the organizer, eligibility, jurisdiction, entry limits, opening and closing times, draw method, winner notification, prize delivery, refunds, and privacy. This demo does not include an approved rulebook or audit certificate.</p></div>
            <div className="rules-links"><a href="mailto:support@example.com">Contact support</a><a href="#payment">Payment instructions</a><span>Official rules: publish before launch</span></div>
          </div>
        </section>
      </main>
      <footer className="footer"><a href="/" className="brand"><span className="brand-mark">P</span><span>PLAY<span className="text-cyan-300">WIN</span></span></a><p>Independent demonstration project. Not affiliated with or endorsed by Sony Interactive Entertainment.</p><div><a href="#rules">Rules</a><a href="mailto:support@example.com">Contact</a><a href="#payment">Payment</a></div><small>© {new Date().getFullYear()} PlayWin Demo. Replace placeholder contact and legal details before launch.</small></footer>
    </>
  );
}

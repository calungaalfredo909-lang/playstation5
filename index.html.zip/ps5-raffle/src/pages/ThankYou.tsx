import { Link, useLocation } from "react-router-dom";
import { CheckCircle2, Clock3 } from "lucide-react";
import type { RaffleEntry } from "../types/raffle";

export default function ThankYou() {
  const location = useLocation();
  const entry = (location.state as { entry?: RaffleEntry } | null)?.entry;
  const mask = (value: string) => value.length > 12 ? `${value.slice(0, 8)}••••${value.slice(-5)}` : "••••••••";
  return <main className="min-h-screen px-5 py-20">
    <div className="mx-auto max-w-xl glass-card text-center">
      <div className="mx-auto mb-5 grid h-16 w-16 place-items-center rounded-full bg-cyan-400/10 text-cyan-300"><CheckCircle2 size={34}/></div>
      <span className="eyebrow">SUBMISSION RECEIVED</span>
      <h1 className="mt-3 text-3xl font-black">Your entry has been <span className="gradient-text">received!</span></h1>
      <p className="mt-4 text-sm leading-7 text-slate-400">Thank you for your submission. Your transaction has not yet been verified. It remains pending until independently checked.</p>
      {entry ? <div className="my-7 space-y-3 rounded-2xl border border-white/10 bg-slate-950/60 p-5 text-left text-sm">
        <div className="flex justify-between gap-4"><span className="text-slate-500">Email</span><b>{entry.email.replace(/^(.{2}).*(@.*)$/, "$1••••$2")}</b></div>
        <div className="flex justify-between gap-4"><span className="text-slate-500">TXID</span><b className="font-mono">{mask(entry.txid)}</b></div>
        <div className="flex justify-between"><span className="text-slate-500">Tickets requested</span><b>{entry.tickets}</b></div>
        <div className="flex justify-between"><span className="text-slate-500">Amount submitted</span><b>${entry.amount} USDT</b></div>
        <div className="flex justify-between"><span className="text-slate-500">Status</span><b className="inline-flex items-center gap-1 text-amber-300"><Clock3 size={14}/> PENDING</b></div>
      </div> : <p className="my-7 rounded-xl bg-amber-400/10 p-4 text-sm text-amber-200">No submission details were passed to this page. Use the tracking page to look up a saved browser entry.</p>}
      <p className="mb-6 text-xs text-slate-500">This browser-only demo does not send email or verify blockchain payments. Keep your TXID for reference.</p>
      <div className="flex flex-col justify-center gap-3 sm:flex-row"><Link to="/track" className="btn-primary">Track my entry</Link><Link to="/" className="btn-secondary">Back to homepage</Link></div>
    </div>
  </main>;
}

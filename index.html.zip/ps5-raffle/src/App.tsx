import { Route, Routes } from "react-router-dom";
import Home from "./pages/Home";
import ThankYou from "./pages/ThankYou";
import TrackEntry from "./pages/TrackEntry";
import ParticipantToast from "./components/ParticipantToast";

export default function App() {
  return <>
    <Routes>
      <Route path="/" element={<Home/>}/>
      <Route path="/thank-you" element={<ThankYou/>}/>
      <Route path="/track" element={<TrackEntry/>}/>
      <Route path="*" element={<Home/>}/>
    </Routes>
    <ParticipantToast/>
  </>;
}

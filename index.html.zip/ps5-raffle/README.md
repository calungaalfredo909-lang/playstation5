# PS5 Raffle — React + TypeScript + Vite

A responsive, dark gaming-style raffle frontend with a PS5-themed product gallery, USDT TRC20 payment instructions, QR code, entry form, local browser storage, demo notifications, thank-you page, and entry lookup.

## Important before going live

This repository is a **frontend demo**, not a payment processor or raffle management system.

- Form submissions are stored only in the participant's browser (`localStorage`).
- A submitted TXID is **not** proof of payment. Entries remain `PENDING` until independently verified.
- No email is sent by this frontend.
- Demo participant notifications, participant counts, and remaining-ticket figures are explicitly labeled as demo content.
- Do not accept real entries or funds until you have confirmed that the raffle is lawful in every relevant jurisdiction, published complete official rules, verified the prize and delivery arrangements, and implemented secure backend payment verification and centralized storage.
- The public wallet address is configured in `src/lib/constants.ts`. Verify it carefully before deployment. Only use USDT on TRON (TRC20).

## Requirements

- Node.js 20+
- npm

## Run locally

```bash
npm install
npm run dev
```

Open the local URL printed by Vite.

## Production build

```bash
npm run build
npm run preview
```

The production site is generated in `dist/`.

## Publish to GitHub

1. Create a new empty repository on GitHub.
2. Extract this project ZIP.
3. Open a terminal inside the `ps5-raffle` folder.
4. Run:

```bash
git init
git add .
git commit -m "Create PS5 raffle website"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Replace the remote URL with your actual GitHub repository URL.

## Deploy to Vercel

1. Sign in at https://vercel.com/.
2. Select **Add New → Project**.
3. Import your GitHub repository.
4. Vercel should detect Vite automatically.
5. Build command: `npm run build`
6. Output directory: `dist`
7. Click **Deploy**.

The included `vercel.json` rewrites app routes to `index.html`, so `/thank-you` and `/track` work after refresh.

## Configuration

Edit `src/lib/constants.ts` to update:
- Wallet address
- Ticket packages
- Raffle end date
- Demo progress figures

The raffle end date is a placeholder. Replace it with the real date and ensure the rules match.

`.env.example` contains optional public Supabase configuration placeholders. Variables prefixed with `VITE_` are bundled into browser code and are **not secret**. Never place a Supabase service-role key or private API key in this frontend.

## Backend integration later

For a production raffle, implement a trusted backend that:
- Validates and deduplicates TXIDs.
- Verifies the transaction on TRON, including token contract, destination wallet, amount, confirmations, and transaction status.
- Stores entries centrally.
- Assigns raffle numbers only after verified payment.
- Sends email confirmations through a server-side provider.
- Enforces ticket inventory and eligibility rules.
- Provides auditable draw records.

Do not trust client-submitted amounts, email addresses, TXIDs, or localStorage records.

## Legal and brand note

Raffles and paid prize draws may be regulated or prohibited depending on location. Obtain qualified legal advice and confirm licensing, age, geographic eligibility, disclosures, privacy, tax, and consumer-protection requirements before accepting money. PlayStation is a trademark of Sony Interactive Entertainment; this independent demo is not affiliated with or endorsed by Sony.
